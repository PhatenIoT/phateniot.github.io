1. 点击LibUsbDotNet_Setup.2.2.8.exe，安装LibUsbDotNet
2. 插入待测USB device
3. 菜单栏打开LibUsbDotNet => Filter Wizard => Install a device filter => 选中待测USB device => 点击Install
4. 打开RtkUsbTestTool，输入待测USB device的VID、PID，点击Scan，如发现设备，Open button会被使能
5. 点击RtkUsbTestTool Open button，输入数据会显示在RX区域，在输出区域输入数据后，点击EP2/EP3 TX，会TX至对应的EP